# Placeholder: Optional Strava sync functions (disabled by default)
# Configure in ride_data/settings.json with STRAVA_CLIENT_ID / SECRET / TOKENS
def connection_status(): return 'Not connected'
